@php 
    $eligibility_data = getEligibilityContent1($value->assigned_eigibility_name);
    $data = getSubmissionStandardizedTesting($submission->id);
@endphp
<form class="form" id="#standardized_testing" method="post" action="{{url('admin/Submissions/update/StandardizedTesting/'.$submission->id)}}">
    {{csrf_field()}}
    <div class="card shadow">
        <div class="card-header">{{$value->eligibility_name}}</div>
        <div class="card-body">
            <div class="form-group custom-none">
                @foreach($eligibility_data->subjects as $key=>$value)
                    <div class="row">
                         <label class="control-label col-12 col-md-12">{{ucfirst($value)}}</label>
                         <div class="col-12  col-md-6 ">
                            <div class="form-group row">
                                <div class="col-12 col-md-12">
                                    <input type="text" class="form-control" value="{{$data[$value]->data ?? ""}}" name="data[]">
                                    <input type="hidden" class="form-control" value="{{$value}}" name="subject[]">
                                </div> 
                            </div>
                        </div>
                        @if($eligibility_data->scoring->type=="SC")
                            <div class="col-12 col-lg-6">
                                <div class="form-group row">
                                    <div class="col-12 col-md-12">
                                        @if($eligibility_data->scoring->method=="CO")
                                             <select class="form-control custom-select template-type" name="method[]">
                                                <option value="">Select Option</option>
                                                @if($eligibility_data->scoring->CO=="NP")
                                                    <option @if(isset($data[$value]->method) && $data[$value]->method == "National Percentage") selected="" @endif>National Percentage</option>
                                                @else
                                                    <option @if(isset($data[$value]->method) && $data[$value]->method == "Raw Score") selected="" @endif>Raw Score</option>
                                                @endif
                                            </select>    
                                        @else
                                            @if($eligibility_data->scoring->method=="YN")
                                                @php $options = $eligibility_data->scoring->YN ;@endphp
                                            @else
                                                @php $options = $eligibility_data->scoring->NR; @endphp
                                            @endif
                                            <select class="form-control custom-select template-type" name="method[]">
                                                <option value="">Select Option</option>
                                                @foreach($options as $k=>$v)
                                                    <option @if(isset($data[$value]->method) && $data[$value]->method == $v) selected="" @endif>{{$v}}</option>
                                                @endforeach
                                            </select> 
                                        @endif
                                        
                                    </div>
                                </div>
                            </div>
                        @endif
                    </div>
                        
                @endforeach
                
            </div>
            <div class="text-right"> 
                <button class="btn btn-success">    
                    <i class="fa fa-save"></i>
                </button>
            </div>
        </div>
    </div>
</form>
