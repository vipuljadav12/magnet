<?php 

return [
    'welcome' => 'Welcome, this is Submissions module.'
];
