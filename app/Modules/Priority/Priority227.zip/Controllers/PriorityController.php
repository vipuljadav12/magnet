<?php

namespace App\Modules\Priority\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Modules\Priority\Models\Priority;
use App\Modules\Priority\Models\PriorityDetail;
use App\Modules\District\Models\District;
use Validator;
use Session;
// use Illuminate\Support\Facades\DB;

class PriorityController extends Controller
{

    public function __construct(){
        // session()->put('district_id', 1);  //26-6-20
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {  
        if(Session::get('district_id') != 0){
            $priorities = Priority::where('district_id', session('district_id'))
                ->where('status', '!=', 'T')
                ->get();
        } 
        else{
            $priorities = Priority::where('status', '!=', 'T')
                ->get();
        }
        return view('Priority::index', compact('priorities'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $district = District::where('id', Session("district_id"))->first(['desegregation_compliance']);
        $desegregation_compliance_status = $district->desegregation_compliance;
        return view('Priority::create', compact('desegregation_compliance_status'));
    }

    /**
     * get checkbox boolean value
     */
    public function getCheckboxBooleanValue($key, $value)
    {
        if(isset($value)){
            return array_key_exists($key,$value)?1:0;
        }
        return '';
    }

    /**
     * Check redundant entries
     */
    public function checkRedundancy(Request $request)
    {
        /*foreach($request->description as $key=>$val){
            if($key==1){
                $combinatios = [];
            } 
            // creating combination
            $combination[$key] = $this->getCheckboxBooleanValue($key,$request->sibling);
            $combination[$key] .= $this->getCheckboxBooleanValue($key,$request->majority_race_in_home_zone_school);
            $combination[$key] .= $this->getCheckboxBooleanValue($key,$request->current_enrollment_at_another_magnet_school);
            // Find redundant entries
            if(array_search($combination[$key], $combinatios)){
                $redundant[] = $key; 
            }
            // Blank entries
            if(preg_match('/1/i', $combination[$key]) == 0){
                $blank[] = $key;
            }
            $combinatios = $combination;
        }  
        if(isset($redundant) || isset($blank)){
            return 0;
        }  
        return 1;*/

        $blank = 0;
        foreach($request->description as $key=>$val){
            if($key==1){
                $combinatios = [];
            } 
            // creating combination
            $combination[$key] = $this->getCheckboxBooleanValue($key,$request->sibling);
            $combination[$key] .= $this->getCheckboxBooleanValue($key,$request->majority_race_in_home_zone_school);
            $combination[$key] .= $this->getCheckboxBooleanValue($key,$request->current_enrollment_at_another_magnet_school);
            // Find redundant entries
            if(array_search($combination[$key], $combinatios)){
                $redundant[] = $key; 
            }
            // Blank entries
            // if(preg_match('/1/i', $combination[$key]) == 0){
            //     // It will skips first blank entry
            //     if($blank > 0){
            //         $blank[] = $key;
            //     }
            //     $blank++;
            // }
            $combinatios = $combination;
        }  
        // if(isset($redundant) || isset($blank)){
        if(isset($redundant)){
            return 0;
        }  
        return 1;
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {       
        // return $request;
        Validator::extend('unique_priority', function($attribute, $value, $parameters) {
            $priority = Priority::where('name', $value)->where('district_id', Session('district_id'))->first();
            if(!isset($priority)){
                return true;
            }
            return false;
        });

        $rules = [
            'name' => 'required|string|max:30|unique_priority',
            'description.*' => 'required|string|max:50',
        ];
        $messages = [
            'name.required' => 'Priority name is required.',
            'description.*.required' => 'Description is required.',
            'unique_priority' => 'Priority already present.'
        ];
        $this->validate($request, $rules, $messages);

        // check redundant entries
        $redundant = $this->checkRedundancy($request);

        if($redundant==1){
            $priority = Priority::create([
                'district_id' => Session("district_id"),
                'name' => $request->name,
            ]);

            if(isset($priority)){
                $i=1;
                $priority_detail=array();

                if(isset($request->sibling))
                    $siblingKeys = array_keys($request->sibling);
                else
                    $siblingKeys = array();
                if(isset($request->majority_race_in_home_zone_school))
                        $majorKeys = array_keys($request->majority_race_in_home_zone_school);
                else
                    $majorKeys = array();

                 if(isset($request->current_enrollment_at_another_magnet_school))
                    $enrolKeys = array_keys($request->current_enrollment_at_another_magnet_school);
                else
                    $enrolKeys = array();


                foreach($request->description as $key=>$val){
                    $priority_detail = ['priority_id'=>$priority->id];
                    if(isset($request->description[$i])){
                        $priority_detail['description'] = $request->description[$i];
                    }
                    else{
                        $priority_detail['description'] = '';
                    }
                    if(count($siblingKeys) > 0 && in_array($key, $siblingKeys))
                    {
                        $priority_detail['sibling'] = 'Y';
                    }
                    else{
                        $priority_detail['sibling'] = 'N';
                    }
                    if(count($majorKeys) > 0 && in_array($key, $majorKeys))
                    {
                        $priority_detail['majority_race_in_home_zone_school'] = 'Y';
                    }
                    else{
                        $priority_detail['majority_race_in_home_zone_school'] = 'N';
                    }
                    if(count($enrolKeys) > 0 && in_array($key, $enrolKeys))
                    {
                        $priority_detail['current_enrollment_at_another_magnet_school'] = 'Y';
                    
                    }
                    else{
                        $priority_detail['current_enrollment_at_another_magnet_school'] = 'N';
                    }
                    $priority_detail_store = PriorityDetail::create($priority_detail);
                    $i++;
                } 
                session()->flash('success', 'Priority added successfully.'); 
            }
            else{
                session()->flash('error', 'Priority not added.');
            }
        }
        else{
            session()->flash('error', 'Do not enter redundant or blank priorities.');
            return redirect('admin/Priority/create');
        }
        
        // return redirect('admin/Priority/create');
        return redirect("admin/Priority");
    }

    /**
     * Check status of priority
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function checkPriorityStatus(Request $request)
    {
        $update_status = Priority::where('id', $request->id)->update(['status' => $request->status]);
        if(isset($update_status)){
            return 'true';
        } 
        return 'false';
    }

    /**
     * Check priority name presence
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function checkPriorityNamePresence(Request $request)
    {   
        $priority = Priority::where('name', $request->name)->where("district_id", $request->district_id)->first();
        
        if(!isset($priority)){
            return 'true';
        } 
        elseif(isset($request->id) && $priority->id==$request->id){
            return 'true';
        }
        return 'false'; 
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $priority = Priority::where('id', $id)
            ->where('district_id', Session("district_id"))
            ->first();
        $priority_details = PriorityDetail::where('priority_id', $id)->get();
        $district = District::where('id', Session("district_id"))->first(['desegregation_compliance']);
        $desegregation_compliance_status = $district->desegregation_compliance;
        return view('Priority::edit', compact('desegregation_compliance_status', 'priority', 'priority_details', 'id'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {  
        Validator::extend('unique_priority', function($attribute, $value, $parameters) {
            $priority = Priority::where('name', $value)->where('district_id', Session('district_id'))->first();
            if(isset($priority)){
                if(isset($parameters[0]) && $parameters[0]==$priority->id){
                    return true;    
                }                    
            }
            else{
                return true;
            }
        }); 
        $rules = [
            'name' => 'required|string|max:30|unique_priority:'.$request->id,
            'description.*' => 'required|string|max:50',
        ];
        $messages = [
            'name.required' => 'Priority name is required.',
            'description.*.required' => 'Description is required.',
            'unique_priority' => 'Priority already present.'

        ];
        $this->validate($request, $rules, $messages);

        // check redundant entries
        $redundant = $this->checkRedundancy($request);

        if($redundant == 1){
            $priority = Priority::where('id', $request->id)
                ->update([
                    'name' => $request->name,
                ]);

            if(isset($priority)){
                $priority_id = ['priority_id'=>$request->id];
                $i=1;
                $priority_detail=array();

                $siblingKeys = array_keys($request->sibling);
                if(isset($request->majority_race_in_home_zone_school))
                        $majorKeys = array_keys($request->majority_race_in_home_zone_school);
                else
                    $majorKeys = array();

                $majorKeys = array_keys($request->majority_race_in_home_zone_school);
                if(isset($request->majority_race_in_home_zone_school))
                        $majorKeys = array_keys($request->majority_race_in_home_zone_school);
                else
                    $majorKeys = array();


                $enrolKeys = array_keys($request->sibling);
                if(isset($request->current_enrollment_at_another_magnet_school))
                        $enrolKeys = array_keys($request->current_enrollment_at_another_magnet_school);
                else
                    $enrolKeys = array();

                //$enrolKeys = array_keys($request->current_enrollment_at_another_magnet_school);



                foreach($request->description as $key=>$val){                
                    $id = ['id'=>$request->priority_detail_id[$i]];
                    if(isset($request->description[$i])){
                        $priority_detail['description'] = $request->description[$i];
                    }
                    else{
                        $priority_detail['description'] = '';
                    }

                    if(count($siblingKeys) > 0 && in_array($key, $siblingKeys))
                    {
                        $priority_detail['sibling'] = 'Y';
                    }
                    else{
                        $priority_detail['sibling'] = 'N';
                    }
                    if(count($majorKeys) > 0 && in_array($key, $majorKeys))
                    {
                        $priority_detail['majority_race_in_home_zone_school'] = 'Y';
                    }
                    else{
                        $priority_detail['majority_race_in_home_zone_school'] = 'N';
                    }
                    if(count($enrolKeys) > 0 && in_array($key, $enrolKeys))
                    {
                        $priority_detail['current_enrollment_at_another_magnet_school'] = 'Y';
                    
                    }
                    else{
                        $priority_detail['current_enrollment_at_another_magnet_school'] = 'N';
                    }

                    $priority_detail_update = PriorityDetail::where('id', $id)
                        ->where('priority_id', $priority_id)
                        ->update($priority_detail);
                    $i++;
                }  
                session()->flash('success', 'Priority updated successfully.');
            }
            else{
                session()->flash('error', 'Priority not updated.');
            }
        }
        else{
            session()->flash('error', 'Do not enter redundant or blank priorities.');
        }
        
        return redirect()->back();
        // return redirect('Priority/add');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function delete($id)
    {   
        $priority_status = Priority::where('id', $id)
            ->update(['status' => 'T']);
        if(isset($priority_status)){
            session()->flash('success', "Priority deleted successfully"); 
        }
        else{
            session()->flash('error', "Priority not deleted");
        }
        return redirect('admin/Priority');
        // $delete_priority_detail = PriorityDetail::where('priority_id', $id)
        //     ->delete();
        // if(isset($delete_priority_detail)){
        //     $delete_priority = Priority::where('id', $id)
        //     ->delete();
        //     if(isset($delete_priority)){
        //         session()->flash('success', "Priority deleted successfully");
        //     }    
        // }
        // else{
        //     session()->flash('error', "Priority not deleted");
        // }
        // return redirect('admin/Priority');
    }

    /**
     * Display a listing of the trashed resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function showTrash()
    {   
        $priorities = Priority::where('district_id', session('district_id'))
            ->where('status', 'T')
            ->get();
        return view('Priority::trash', compact('priorities'));
    }

    /**
     * Restore from trash.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function restoreFromTrash($id)
    {   
        $priority_status = Priority::where('id', $id)
            ->update(['status' => 'Y']);
        if(isset($priority_status)){
            session()->flash('success', "Priority restored successfully"); 
        }
        else{
            session()->flash('error', "Priority not restored");
        }
        return redirect('admin/Priority/trash');
    }
}
