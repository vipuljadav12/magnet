<?php

namespace App\Modules\Priority\Models;

use Illuminate\Database\Eloquent\Model;

class Priority extends Model {

    protected $fillable = [
    	'name', 'district_id',
    ];

}
