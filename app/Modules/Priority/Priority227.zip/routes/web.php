<?php

Route::group(['prefix'=>'admin/Priority', 'module' => 'Priority', 'middleware' => ['web', 'auth'], 'namespace' => 'App\Modules\Priority\Controllers'], function() {

	Route::get('/', 'PriorityController@index');
	Route::get('/create', 'PriorityController@create');
	Route::post('/store', 'PriorityController@store');
	Route::get('/edit/{id}', 'PriorityController@edit');
	Route::post('/update', 'PriorityController@update');
	Route::get('/delete/{id}', 'PriorityController@delete');
	Route::get('/trash', 'PriorityController@showTrash');
	Route::get('/restore/{id}', 'PriorityController@restoreFromTrash');

	Route::post('/checkPriorityNamePresence', 'PriorityController@checkPriorityNamePresence');
	Route::post('/priority_status', 'PriorityController@checkPriorityStatus');
});
