    <div class="mt-20">
        <div class="card bg-light p-20">
            <div class="text-center font-20 b-600 mb-10">{!! getconfig()['welcome_text'] ?? '' !!}</div>
            <div class="">
                {!! getconfig()['welcome_message'] ?? '' !!}
            </div>
        </div>
    </div>
