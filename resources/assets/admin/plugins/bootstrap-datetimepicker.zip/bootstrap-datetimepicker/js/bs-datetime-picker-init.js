(function() {
    "use strict"

	jQuery('.datetimepicker1').datetimepicker({format: 'yyyy-mm-dd hh:ii',autoclose: true,});

	
})(jQuery);