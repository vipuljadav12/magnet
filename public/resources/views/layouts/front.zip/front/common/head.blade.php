<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" href="{{url('/')}}/resources/assets/front/images/favicon2.png" type="image/x-icon" />
<title>{{ $district->name ?? '' }}</title>
<link rel="stylesheet" href="{{url('/')}}/resources/assets/admin/plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css">
<link rel="stylesheet" href="{{url('/')}}/resources/assets/admin/css/switchery.min.css">

<link rel="stylesheet" href="{{url('/')}}/resources/assets/front/css/main.css">
<style type="text/css">
    
.bg-secondary{
    background-color:{{Session::get("theme_color")}} !!important; 
}
</style>