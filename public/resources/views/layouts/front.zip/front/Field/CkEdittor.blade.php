<div class="form-group">
	{!!$data['description']!!}
</div>